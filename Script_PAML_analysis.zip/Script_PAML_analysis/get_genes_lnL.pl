#!/usr/bin/perl -w

#use strict;
#use warnings;
use Getopt::Long;
use File::Basename;
use File::Spec;

my ($dir);
my $help=0;

GetOptions (
  'd=s'         => \$dir,
  'help|h!'     => \$help,
  ) or die "Inappropriate parameter\n";

if ($help) {
print << "EOF";

-d      followed with the name of directory who contain all alignment files.
-help/h for help imformation.

EOF
exit;
 }

my @files=<$dir/*>;

foreach my $work_dir (@files){
	chdir $work_dir;
	opendir(DIR,'./');
	my $group_name;
	while(my $file = readdir(DIR)){
		if($file =~ /\.out/){
			$group_name = basename $file;
                	#$group_name =~ s/(.*)\.aln\.out/$1/;
			$group_name =~ s/(.*)\.out/$1/;

		}
	}
	#print"now run $group_name\n";
	$fileExist = -e "$group_name.out";
	if($fileExist){
 	open (IN,"$group_name.out") or die;  
	#open (OUT1,">>../../out_kaks_Trosa_m2_w1.txt") or die;
	while (<IN>) {  
		chomp;  
		if (/lnL/) { #..1000.2000........LZ...........  
 			#print OUT1 "$group_name\t$_\n";} 
 			print "$group_name\t$_\n";}
 		}  
	}
	seek(IN,0,0);
	close IN;  
	#close OUT; 
	chdir '../..';
}
