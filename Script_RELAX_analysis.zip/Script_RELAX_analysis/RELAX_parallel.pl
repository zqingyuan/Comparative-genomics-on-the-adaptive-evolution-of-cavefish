#!/usr/bin/perl -w

#use strict;
#use warnings;
use Getopt::Long;
use File::Basename;
use lib "/data/qingyuan/perl/PerlLib";
use lib "/home/test/zhaoqingyuan/biosoft/NGSQCToolkit_v2.3.3/QC/lib/";
use Parallel::ForkManager;

my ($tree, $ctl, $dir);
my $cpus=1;
my $help=0;
chomp( my $work_d=`pwd`);
print"$work_d\n";

GetOptions (
  't=s'         => \$tree,
  'd=s'         => \$dir,
  'n=i'         => \$cpus,
  'help|h!'     => \$help,
  ) or die "Inappropriate parameter\n";

if ($help) {
print << "EOF";


-t      followed with .tree profile.
-d      followed with the name of directory who contain all alignment files.
-n      followed with cpus number you want to put in this work <default 1>.
-help/h for help infomation.

EOF
exit;
 }

`mkdir out_K`;
my @files=<$dir/*>;
my @files_tree=<$tree/*>;

for ($i=0; $i<=$cpus-1; $i++) {
`mkdir $i`;
`mkdir $i/align`;
`mkdir $i/tree`;

}

for ($i=0; $i<=@files-1; $i++) {    # distribute alignments.
$dir_to=$i % $cpus;                    
`cp $files[$i] $dir_to/align`;
`cp $files_tree[$i] $dir_to/tree`;
}

######## preparatory work done. including
                              # 1.make work directory for each parallels; 
                              # 2.cope .ctl .tree in; 
                              # 3.distribute alignments evenly to each work directory ########

######## start parallels ###################
my $max_process = 100;
my $pm = new Parallel::ForkManager($max_process);

my $work_dir; 
for ($i=0; $i<=$cpus-1; $i++) {
  $pm -> start and next;
     $work_dir="$work_d/$i";
     chdir $work_dir;
     &codeml;
  $pm -> finish;
}

$pm -> wait_all_children;  #reep
`rm -r [0-9]*`;
print "all finish\n";

####### codeml function ###################
sub codeml{
  my @names=<align/*>;
  foreach my $filname (@names) {
    my $basename = basename $filname;
    $basename =~ s/\.aln//;
    `mkdir ../out_K/$basename/`;
    `cp $filname ../out_K/$basename/`;
    `cp ./tree/$basename.nwk ../out_K/$basename/`;
    my $gene_dir = "../out_K/$basename";
    chdir $gene_dir;
    my $exe = `pwd`; 
    print"exedir is $exe\n";
    `hyphy RELAX --alignment $basename.aln --tree $basename.nwk --test surface --reference cave --CPU 1`;
    chdir $work_dir;
  }
}
