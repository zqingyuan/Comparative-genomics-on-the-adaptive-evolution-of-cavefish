#!/usr/bin/perl -w

#use strict;
#use warnings;
use Getopt::Long;
use File::Basename;
use File::Spec;

my ($dir);
my $help=0;

GetOptions (
  'd=s'         => \$dir,
  'help|h!'     => \$help,
  ) or die "Inappropriate parameter\n";

if ($help) {
print << "EOF";

-d      followed with the name of directory who contain all alignment files.
-help/h for help imformation.
welcome to communicate.

EOF
exit;
 }

my @files=<$dir/*>;

foreach my $work_dir (@files){
	chdir $work_dir;
	opendir(DIR,'./');
	my $group_name;
	while(my $file = readdir(DIR)){
		if($file =~ /\.aln\.RELAX\.json/){
			$group_name = basename $file;
                	#$group_name =~ s/(.*)\.aln\.out/$1/;
			$group_name =~ s/(.*)\.aln\.RELAX\.json/$1/;

		}
	}
	#print"now run $group_name\n";
	$fileExist = -e "$group_name.aln.RELAX.json";
	if($fileExist){
 	open (IN,"$group_name.aln.RELAX.json") or die;  
	my $LRT;
	my $pvalue;
	my $k;
	#open (OUT1,">>../../out_kaks_Trosa_m2_w1.txt") or die;
	while (<IN>) {  
			chomp;  
			if (/test results/) { 
 				$LRT = <IN>;
				$pvalue = <IN>;
				$k  = <IN>;
				chomp($LRT,$pvalue,$k);
			}
 		}
		my @LRT_l = split /:/, $LRT;
		my @pvalue_l = split /:/, $pvalue;
		my @k_l = split /:/, $k;
		print"$group_name\t$LRT_l[1]\t$pvalue_l[1]\t$k_l[1]\n"; 
	}
	seek(IN,0,0);
	close IN;  
	#close OUT; 
	chdir '../..';
}
