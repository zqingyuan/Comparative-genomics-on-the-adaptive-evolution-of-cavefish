#!/usr/bin/perl -w

#use strict;
#use warnings;
use Getopt::Long;
use File::Basename;
use File::Spec;

my ($dir);
my $help=0;

GetOptions (
  'd=s'         => \$dir,
  'help|h!'     => \$help,
  ) or die "Inappropriate parameter\n";

if ($help) {
print << "EOF";

-d      followed with the name of directory who contain all alignment files.
-help/h for help imformation.
welcome to communicate.

EOF
exit;
 }

my @files=<$dir/*>;

foreach my $work_dir (@files){
	chdir $work_dir;
	opendir(DIR,'./');
	my $group_name;
	while(my $file = readdir(DIR)){
		if($file =~ /\.out/){
			$group_name = basename $file;
                	#$group_name =~ s/(.*)\.aln\.out/$1/;
			$group_name =~ s/(.*)\.out/$1/;

		}
	}
	#print"now run $group_name\n";
	$fileExist = -e "$group_name.out";
	if($fileExist){
 	open (IN,"$group_name.out") or die;  
	#open (OUT1,">>../../no_cacul_ID.txt") or die;
	while (<IN>) {  
		chomp;  
		if (/tree length/) { #..1000.2000........LZ...........  
			#my $line1 = <IN>;
			#if($line1 =~ /Trosa:/){
			#$line1=~/Trosa: (\d\.\d+)/;
 			#print OUT1 "$group_name\t$1\n";} 
			#print"$group_name\n";
			next;
 		}#else{print "$group_name\n";}  
	}
	seek(IN,0,0);
	close IN;  
	#close OUT; 
	chdir '../..';
}}
