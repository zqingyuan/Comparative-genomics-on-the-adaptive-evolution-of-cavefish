#!/usr/bin/perl -w

#use strict;
#use warnings;
use Getopt::Long;
use File::Basename;
use lib "/data/qingyuan/perl/PerlLib";
use lib "/home/test/zhaoqingyuan/biosoft/NGSQCToolkit_v2.3.3/QC/lib/";
use Parallel::ForkManager;

my ($tree, $ctl, $dir);
my $cpus=1;
my $help=0;
chomp( my $work_d=`pwd`);
print"$work_d\n";

GetOptions (
  't=s'         => \$tree,
  'c=s'         => \$ctl,
  'd=s'         => \$dir,
  'n=i'         => \$cpus,
  'help|h!'     => \$help,
  ) or die "Inappropriate parameter\n";

if ($help) {
print << "EOF";


-t      followed with .tree profile.
-c      followed with .ctl profile.
-d      followed with the name of directory who contain all alignment files.
-n      followed with cpus number you want to put in this work <default 1>.
-help/h for help infomation.

NOTE!!! 
Tree and ctl should in the current directory.
The "seqfile=", "treefile=", "outfile=" should be the first three lines in .ctl file.

EOF
exit;
 }

`mkdir out_kaks`;
my @files=<$dir/*>;
my @files_tree=<$tree/*>;

for ($i=0; $i<=$cpus-1; $i++) {
`mkdir $i`;
`mkdir $i/align`;
`mkdir $i/tree`;

`cp $ctl $i`;
}

for ($i=0; $i<=@files-1; $i++) {    # distribute alignments.
$dir_to=$i % $cpus;                    
`cp $files[$i] $dir_to/align`;
`cp $files_tree[$i] $dir_to/tree`;
}

######## preparatory work done. including
                              # 1.make work directory for each parallels; 
                              # 2.cope .ctl .tree in; 
                              # 3.distribute alignments evenly to each work directory ########

######## start parallels ###################
my $max_process = 100;
my $pm = new Parallel::ForkManager($max_process);

my $work_dir; 
for ($i=0; $i<=$cpus-1; $i++) {
  $pm -> start and next;
     $work_dir="$work_d/$i";
     chdir $work_dir;
     &codeml;
  $pm -> finish;
}

$pm -> wait_all_children;  #reep
`rm -r [0-9]*`;
print "all finish\n";

####### codeml function ###################
sub codeml{
  my @names=<align/*>;
  foreach my $filname (@names) {
    my $basename = basename $filname;
    $basename =~ s/\.aln//;
    `mkdir ../out_kaks/$basename/`;
    #`sed -i -e "1cseqfile = $filname" -e "2ctreefile = $tree" -e "3coutfile = ../out/$basename.mlc" $ctl`;
    #`sed -i -e "1cseqfile = $filname" -e "2ctreefile = $tree" -e "3coutfile = ../out/$basename/$basename.out" $ctl`;
    `cp $filname ../out_kaks/$basename/`;
    `cp ./tree/$basename.nwk ../out_kaks/$basename/`;
    #my $seq_name;
    #my $tree_name;
    #if($basename =~ /\.phy/){
    #	$seq_name = $basename;
    #}elsif(/\.nwk/){
    #	$tree_name = $basename;
    #}
    `sed -i -e "1cseqfile = $basename.aln" -e "2ctreefile = $basename.nwk" -e "3coutfile = $basename.out" $ctl`;
    `cp $ctl ../out_kaks/$basename/`;
    my $gene_dir = "../out_kaks/$basename";
    chdir $gene_dir;
    my $exe = `pwd`; 
    print"exedir is $exe\n";
    `codeml $ctl`;
    chdir $work_dir;
  }
}
