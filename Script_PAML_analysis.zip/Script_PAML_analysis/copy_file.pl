
use strict;
use warnings;
open FILEA,"$ARGV[0]" or die "couldn't open the file:$!";

my @geneID;
while(<FILEA>){
    chomp;
	#my @line = split /\t/, $_;
	#push @geneID,$line[0]; 
	push @geneID,$_;
}

foreach(@geneID){

	#`cp ./all_Trosa_tree/$_.nwk ./no_cacul_1627_tre/$_.nwk`;
	`cp ./all_Trosa_aln/$_.aln ./no_cacul_1627_aln/$_.aln`;

}
